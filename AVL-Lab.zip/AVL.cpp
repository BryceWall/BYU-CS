#include "AVL.h"
#include <iostream>

using namespace std;

  AVL::AVL(){
    root = NULL;
    treeSize = 0;
  }
  AVL::~AVL(){
    clear();
  }

  bool find(Node* T, int val) {
    if(T == NULL){
      return false;
    }
    if(T->value == val){
      return true;
    }
    if(val < T->value){
      return find(T->left, val);
    }
    if(val > T->value){
      return find(T->right, val);
    }
  }

  NodeInterface * AVL::getRootNode() const {
    return root;
  }

  bool AVL::add(int data) {
    return insert(root, data);
  }

  bool AVL::insert(Node* &T, int data) {
    if(find(T,data)){
      return false;
    }
    if(T == NULL){
      T = new Node(data);
      treeSize++;
      return true;
    }
    if(T->value == data){
      return false;
    }
    else if(data < T->value){
      return insert(T->left, data);
    }
    else {
      return insert(T->right, data);
    }
  }

 	bool AVL::unInsert(Node* &removal, int data) {
    if(!find(removal, data)){
      return false;
    }
    if(removal == NULL){
      return false;
    }
    if(data < removal->value){
      return unInsert(removal->left, data);
    }
    if(data > removal->value){
      return unInsert(removal->right, data);
    }
    else {
      if(hasNoChildren(removal)){
        delete removal;
        removal = NULL;
        treeSize--;
        return true;
      }
      else if(hasTwoChildren(removal)){
        int n = highestNode(removal->left);
        unInsert(removal->left, n);
        removal->value = n;
        treeSize--;
        return true;
      }
      else if(hasLeftChild(removal)){
        Node *current = removal;
        removal = current->left;
        delete current;
        treeSize--;
        return true;
      }
      else if(hasRightChild(removal)){
        Node *current = removal;
        removal = current->right;
        delete current;
        treeSize--;
        return true;
      }
    }
  }

  bool AVL::remove(int data) {
    return unInsert(root, data);
  }

  void AVL::clear() {
    while (root != NULL){
      remove(root->value);
    }
    treeSize = 0;
  }
